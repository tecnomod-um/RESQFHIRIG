# InHospital ValueSet - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **InHospital ValueSet**

## ValueSet: InHospital ValueSet 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/ValueSet/in-hospital-vs | *Version*:1.1.0 |
| Active as of 2026-11-06 | *Computable Name*:InHospitalVS |

 
Allowed coded values for InHospital 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "in-hospital-vs",
  "url" : "http://qualityregistry.org/ValueSet/in-hospital-vs",
  "version" : "1.1.0",
  "name" : "InHospitalVS",
  "title" : "InHospital ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-06T09:38:16+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Allowed coded values for InHospital",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/in-hospital",
      "concept" : [{
        "code" : "false",
        "display" : "False"
      },
      {
        "code" : "true",
        "display" : "True"
      },
      {
        "code" : "none",
        "display" : "None"
      }]
    }]
  }
}

```
