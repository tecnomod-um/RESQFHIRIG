# ScreeningPerformer ValueSet - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ScreeningPerformer ValueSet**

## ValueSet: ScreeningPerformer ValueSet 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/ValueSet/screening-performer-vs | *Version*:1.1.0 |
| Active as of 2026-11-05 | *Computable Name*:ScreeningPerformerVS |

 
Allowed coded values for ScreeningPerformer 

 **References** 

* [RESQ PractitionerRole Profile](StructureDefinition-resq-practitioner-role-profile.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "screening-performer-vs",
  "url" : "http://qualityregistry.org/ValueSet/screening-performer-vs",
  "version" : "1.1.0",
  "name" : "ScreeningPerformerVS",
  "title" : "ScreeningPerformer ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-05T10:11:29+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Allowed coded values for ScreeningPerformer",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "106292003",
        "display" : "Professional nurse (occupation)"
      },
      {
        "code" : "309343006",
        "display" : "Physician (occupation)"
      },
      {
        "code" : "223366009",
        "display" : "Healthcare professional (occupation)"
      },
      {
        "code" : "159026005",
        "display" : "Speech and language therapist"
      }]
    }]
  }
}

```
