# StrokeDischargeSummarySectionCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeDischargeSummarySectionCs CodeSystem**

## CodeSystem: StrokeDischargeSummarySectionCs CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/CodeSystem/stroke-discharge-summary-section-cs | *Version*:1.1.0 |
| Active as of 2026-11-06 | *Computable Name*:StrokeDischargeSummarySectionCS |

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/stroke-discharge-summary-section-cs. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [RESQ Stroke Discharge Section Code ValueSet](ValueSet-resq-stroke-discharge-section-code-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "stroke-discharge-summary-section-cs",
  "url" : "http://qualityregistry.org/CodeSystem/stroke-discharge-summary-section-cs",
  "version" : "1.1.0",
  "name" : "StrokeDischargeSummarySectionCS",
  "title" : "StrokeDischargeSummarySectionCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-06T09:50:34+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/stroke-discharge-summary-section-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "treatment-timings",
    "display" : "Treatment Timings"
  }]
}

```
