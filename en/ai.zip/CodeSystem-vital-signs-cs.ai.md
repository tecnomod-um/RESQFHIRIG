# VitalSignsCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.0.0

## CodeSystem: VitalSignsCs CodeSystem 

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://tecnomod-um.org/CodeSystem/vital-signs-cs. 

This Code system is referenced in the definition of the following value sets:

* [VitalSignsVS](ValueSet-vital-signs-vs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "vital-signs-cs",
  "url" : "http://tecnomod-um.org/CodeSystem/vital-signs-cs",
  "version" : "1.0.0",
  "name" : "VitalSignsCS",
  "title" : "VitalSignsCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-03T14:48:08+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://tecnomod-um.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://tecnomod-um.org/CodeSystem/vital-signs-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "highest-sys-bp",
    "display" : "Highest Systolic Blood Pressure"
  }]
}

```
