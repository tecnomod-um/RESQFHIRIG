# IvtApplicationDepartment ValueSet - RESQ Stroke Registry Implementation Guide v1.0.0

## ValueSet: IvtApplicationDepartment ValueSet 

 
Allowed coded values for IvtApplicationDepartment 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ivt-application-department-vs",
  "url" : "http://tecnomod-um.org/ValueSet/ivt-application-department-vs",
  "version" : "1.0.0",
  "name" : "IvtApplicationDepartmentVS",
  "title" : "IvtApplicationDepartment ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-13T14:14:43+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://tecnomod-um.org"
    }]
  }],
  "description" : "Allowed coded values for IvtApplicationDepartment",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
      "concept" : [{
        "code" : "HRAD",
        "display" : "radiology unit"
      },
      {
        "code" : "ICU",
        "display" : "Intensive Care Unit"
      },
      {
        "code" : "ER",
        "display" : "Emergency room"
      },
      {
        "code" : "other",
        "display" : "Other Department"
      }]
    }]
  }
}

```
