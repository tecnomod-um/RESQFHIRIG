# LocationCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.0.0

## CodeSystem: LocationCs CodeSystem 

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://tecnomod-um.org/CodeSystem/location-cs. 

This Code system is referenced in the definition of the following value sets:

* [AdmissionDepartmentVS](ValueSet-admission-department-vs.md)
* [FirstContactPlaceVS](ValueSet-first-contact-place-vs.md)
* [IvtApplicationDepartmentVS](ValueSet-ivt-application-department-vs.md)
* [LocationsVS](ValueSet-locations-vs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "location-cs",
  "url" : "http://tecnomod-um.org/CodeSystem/location-cs",
  "version" : "1.0.0",
  "name" : "LocationCS",
  "title" : "LocationCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-03T14:48:08+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://tecnomod-um.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://tecnomod-um.org/CodeSystem/location-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 2,
  "concept" : [{
    "code" : "other",
    "display" : "Other Location"
  },
  {
    "code" : "unknown",
    "display" : "Unknown Location"
  }]
}

```
