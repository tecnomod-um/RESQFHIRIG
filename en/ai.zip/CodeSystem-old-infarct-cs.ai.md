# OldInfarctCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.0.0

## CodeSystem: OldInfarctCs CodeSystem 

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://tecnomod-um.org/CodeSystem/old-infarct-cs. 

This Code system is referenced in the definition of the following value sets:

* [SpecificFindingVS](ValueSet-specific-finding-vs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "old-infarct-cs",
  "url" : "http://tecnomod-um.org/CodeSystem/old-infarct-cs",
  "version" : "1.0.0",
  "name" : "OldInfarctCS",
  "title" : "OldInfarctCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-05-13T14:14:43+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://tecnomod-um.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://tecnomod-um.org/CodeSystem/old-infarct-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "old-infarct",
    "display" : "Old Infarct"
  }]
}

```
