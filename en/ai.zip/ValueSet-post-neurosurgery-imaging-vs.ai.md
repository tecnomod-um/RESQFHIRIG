# PostNeurosurgeryImaging ValueSet - RESQ Stroke Registry Implementation Guide v1.0.0

## ValueSet: PostNeurosurgeryImaging ValueSet 

 
Allowed coded values for PostNeurosurgeryImaging 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "post-neurosurgery-imaging-vs",
  "url" : "http://tecnomod-um.org/ValueSet/post-neurosurgery-imaging-vs",
  "version" : "1.0.0",
  "name" : "PostNeurosurgeryImagingVS",
  "title" : "PostNeurosurgeryImaging ValueSet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-03T14:48:08+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://tecnomod-um.org"
    }]
  }],
  "description" : "Allowed coded values for PostNeurosurgeryImaging",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "396205005",
        "display" : "Computed tomography of brain without radiopaque contrast (procedure)"
      }]
    },
    {
      "system" : "http://tecnomod-um.org/CodeSystem/brain-imaging-type-cs",
      "concept" : [{
        "code" : "mr",
        "display" : "MR"
      },
      {
        "code" : "no",
        "display" : "No Imaging"
      }]
    }]
  }
}

```
