# StrokeArrivalModeCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeArrivalModeCs CodeSystem**

## CodeSystem: StrokeArrivalModeCs CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/CodeSystem/stroke-arrival-mode-cs | *Version*:1.0.0 |
| Active as of 2026-08-31 | *Computable Name*:StrokeArrivalModeCS |

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/stroke-arrival-mode-cs. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [AdmissionPathway ValueSet](ValueSet-admission-pathway-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "stroke-arrival-mode-cs",
  "url" : "http://qualityregistry.org/CodeSystem/stroke-arrival-mode-cs",
  "version" : "1.0.0",
  "name" : "StrokeArrivalModeCS",
  "title" : "StrokeArrivalModeCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-31T10:08:26+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/stroke-arrival-mode-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "ems-home",
    "display" : "patient arrived by EMS/ambulance from home/scene"
  },
  {
    "code" : "ems-gp",
    "display" : "patient arrived by EMS/ambulance from general practitioner/outpatient office/community service"
  },
  {
    "code" : "priv-transport",
    "display" : "patient arrived by private transportation from home/scene"
  },
  {
    "code" : "stroke-center",
    "display" : "patient arrived from stroke treating center"
  },
  {
    "code" : "another-hosp",
    "display" : "patient arrived from hospital that is not stroke treating center"
  },
  {
    "code" : "priv-transport-gp",
    "display" : "patient arrived by private transportation from general practitioner/outpatient office/community service"
  },
  {
    "code" : "in-hospital-stroke",
    "display" : "stroke while hospitalized in another department of the same hospital"
  }]
}

```
