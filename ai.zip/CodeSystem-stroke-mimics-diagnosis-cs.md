# StrokeMimicsDiagnosisCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StrokeMimicsDiagnosisCs CodeSystem**

## CodeSystem: StrokeMimicsDiagnosisCs CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/CodeSystem/stroke-mimics-diagnosis-cs | *Version*:1.1.0 |
| Active as of 2026-09-23 | *Computable Name*:StrokeMimicsDiagnosisCS |

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/stroke-mimics-diagnosis-cs. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [MimicsDiagnosis ValueSet](ValueSet-mimics-diagnosis-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "stroke-mimics-diagnosis-cs",
  "url" : "http://qualityregistry.org/CodeSystem/stroke-mimics-diagnosis-cs",
  "version" : "1.1.0",
  "name" : "StrokeMimicsDiagnosisCS",
  "title" : "StrokeMimicsDiagnosisCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-23T10:52:57+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/stroke-mimics-diagnosis-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "other",
    "display" : "Other Stroke Mimics Diagnosis"
  }]
}

```
