# VteProceduresCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VteProceduresCs CodeSystem**

## CodeSystem: VteProceduresCs CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/CodeSystem/vte-procedures-cs | *Version*:1.1.0 |
| Active as of 2026-09-23 | *Computable Name*:VteProceduresCS |

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/vte-procedures-cs. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VteProcedures ValueSet](ValueSet-vte-procedures-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "vte-procedures-cs",
  "url" : "http://qualityregistry.org/CodeSystem/vte-procedures-cs",
  "version" : "1.1.0",
  "name" : "VteProceduresCS",
  "title" : "VteProceduresCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-23T10:52:36+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/vte-procedures-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "vte-proc",
    "display" : "Thromboembolism intervention"
  }]
}

```
