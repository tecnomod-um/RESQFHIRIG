# ExampleStrokeEncounter - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExampleStrokeEncounter**

## Example Encounter: ExampleStrokeEncounter

Profile: [Stroke Encounter Profile](StructureDefinition-stroke-encounter-profile.md)

**First hospital for the stroke episode**: [Organization Example Healthcare Organization](Organization-OrganizationExample.md)

**Required post-acute care**: false

**EMS prenotification**: true

**status**: Completed

**subject**: [Anonymous Patient (no stated gender), DoB Unknown ( patient-001)](Patient-ExampleRESQPatient.md)

### Admissions

| | | |
| :--- | :--- | :--- |
| - | **AdmitSource** | **DischargeDisposition** |
| * | EMS from GP | Discharge to home (procedure) |



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "ExampleStrokeEncounter",
  "meta" : {
    "profile" : ["http://qualityregistry.org/StructureDefinition/stroke-encounter-profile"]
  },
  "extension" : [{
    "url" : "http://qualityregistry.org/StructureDefinition/first-hospital-ext",
    "valueReference" : {
      "reference" : "Organization/OrganizationExample"
    }
  },
  {
    "url" : "http://qualityregistry.org/StructureDefinition/required-post-acute-care-ext",
    "valueBoolean" : false
  },
  {
    "url" : "http://qualityregistry.org/StructureDefinition/ems-prenotification-ext",
    "valueBoolean" : true
  }],
  "status" : "completed",
  "subject" : {
    "reference" : "Patient/ExampleRESQPatient"
  },
  "admission" : {
    "admitSource" : {
      "coding" : [{
        "system" : "http://qualityregistry.org/CodeSystem/stroke-arrival-mode-cs",
        "code" : "ems-gp",
        "display" : "EMS from GP"
      }]
    },
    "dischargeDisposition" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "306689006",
        "display" : "Discharge to home (procedure)"
      }]
    }
  }
}

```
