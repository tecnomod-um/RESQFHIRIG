# HemorrhagicTransformationTypeCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HemorrhagicTransformationTypeCs CodeSystem**

## CodeSystem: HemorrhagicTransformationTypeCs CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/CodeSystem/hemorrhagic-transformation-type-cs | *Version*:1.0.0 |
| Active as of 2026-08-31 | *Computable Name*:HemorrhagicTransformationTypeCS |

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/hemorrhagic-transformation-type-cs. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HemorrhagicTransformationType ValueSet](ValueSet-hemorrhagic-transformation-type-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "hemorrhagic-transformation-type-cs",
  "url" : "http://qualityregistry.org/CodeSystem/hemorrhagic-transformation-type-cs",
  "version" : "1.0.0",
  "name" : "HemorrhagicTransformationTypeCS",
  "title" : "HemorrhagicTransformationTypeCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-31T10:08:26+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/hemorrhagic-transformation-type-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "hi-type-1",
    "display" : "HI type 1"
  },
  {
    "code" : "hi-type-2",
    "display" : "HI type 2"
  },
  {
    "code" : "ph-type-1",
    "display" : "PH type 1"
  },
  {
    "code" : "ph-type-2",
    "display" : "PH type 2"
  }]
}

```
