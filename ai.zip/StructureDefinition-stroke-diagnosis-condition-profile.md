# Stroke Diagnosis Condition Profile - RESQ Stroke Registry Implementation Guide v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stroke Diagnosis Condition Profile**

## Resource Profile: Stroke Diagnosis Condition Profile 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/StructureDefinition/stroke-diagnosis-condition-profile | *Version*:1.1.0 |
| Active as of 2026-10-14 | *Computable Name*:StrokeDiagnosisConditionProfile |

 
Condition profile for the index stroke diagnosis. It captures stroke type, onset timing, body site, diagnostic evidence and stroke-specific classification extensions such as ischemic etiology, hemorrhagic bleeding reason and wake-up stroke status. 

 
Represents the principal clinical diagnosis around which the registry episode is organized. 

**Usages:**

* Refer to this Perfil: [RESQ Stroke Discharge Patient Summary Composition](StructureDefinition-resq-stroke-discharge-composition.md) and [Stroke Reperfusion Procedure Profile](StructureDefinition-stroke-mechanical-procedure-profile.md)
* Examples for this Perfil: [Condition/ExampleStrokeDiagnosis](Condition-ExampleStrokeDiagnosis.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/RESQFHIRIG|current/StructureDefinition/StructureDefinition-stroke-diagnosis-condition-profile.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-stroke-diagnosis-condition-profile.csv), [Excel](StructureDefinition-stroke-diagnosis-condition-profile.xlsx), [Schematron](StructureDefinition-stroke-diagnosis-condition-profile.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "stroke-diagnosis-condition-profile",
  "url" : "http://qualityregistry.org/StructureDefinition/stroke-diagnosis-condition-profile",
  "version" : "1.1.0",
  "name" : "StrokeDiagnosisConditionProfile",
  "title" : "Stroke Diagnosis Condition Profile",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-14T14:44:50+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Condition profile for the index stroke diagnosis. It captures stroke type, onset timing, body site, diagnostic evidence and stroke-specific classification extensions such as ischemic etiology, hemorrhagic bleeding reason and wake-up stroke status.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "purpose" : "Represents the principal clinical diagnosis around which the registry episode is organized.",
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 V2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Condition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Condition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Condition",
      "path" : "Condition",
      "constraint" : [{
        "key" : "ischemic-etiology-only-for-ischemic-stroke",
        "severity" : "error",
        "human" : "Ischemic stroke etiology extension should only be present when the diagnosis code is ischemic stroke.",
        "expression" : "extension.where(url = 'http://qualityregistry.org/StructureDefinition/ischemic-stroke-etiology-ext').exists().not() or code.coding.where(system = 'http://snomed.info/sct' and code = '422504002').exists()",
        "source" : "http://qualityregistry.org/StructureDefinition/stroke-diagnosis-condition-profile"
      },
      {
        "key" : "hemorrhagic-bleeding-reason-only-for-hemorrhagic-stroke",
        "severity" : "error",
        "human" : "Hemorrhagic bleeding reason extension should only be present when the diagnosis code is hemorrhagic stroke or subarachnoid hemorrhage.",
        "expression" : "extension.where(url = 'http://qualityregistry.org/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext').exists().not() or code.coding.where(system = 'http://snomed.info/sct' and (code = '274100004' or code = '21454007')).exists()",
        "source" : "http://qualityregistry.org/StructureDefinition/stroke-diagnosis-condition-profile"
      },
      {
        "key" : "wakeup-stroke-true-should-have-onset",
        "severity" : "warning",
        "human" : "If wake-up stroke is true, onsetDateTime should be populated with the last-known-well or sleep timestamp.",
        "expression" : "extension.where(url = 'http://qualityregistry.org/StructureDefinition/wakeup-stroke-ext').value.ofType(boolean) != true or onset.exists()",
        "source" : "http://qualityregistry.org/StructureDefinition/stroke-diagnosis-condition-profile"
      },
      {
        "key" : "mimic-diagnosis-should-not-have-stroke-specific-extensions",
        "severity" : "error",
        "human" : "If the diagnosis code belongs to MimicsDiagnosisVS, stroke-specific etiology or hemorrhagic bleeding reason extensions should not be present.",
        "expression" : "code.memberOf('http://qualityregistry.org/ValueSet/mimics-diagnosis-vs').not() or (extension.where(url = 'http://qualityregistry.org/StructureDefinition/ischemic-stroke-etiology-ext').exists().not() and extension.where(url = 'http://qualityregistry.org/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext').exists().not())",
        "source" : "http://qualityregistry.org/StructureDefinition/stroke-diagnosis-condition-profile"
      }]
    },
    {
      "id" : "Condition.extension",
      "path" : "Condition.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Condition.extension:ischemicStrokeEtiology",
      "path" : "Condition.extension",
      "sliceName" : "ischemicStrokeEtiology",
      "short" : "Known ischemic stroke etiology",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://qualityregistry.org/StructureDefinition/ischemic-stroke-etiology-ext"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.extension:hemorrhagicStrokeBleedingReason",
      "path" : "Condition.extension",
      "sliceName" : "hemorrhagicStrokeBleedingReason",
      "short" : "Known hemorrhagic bleeding reason",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://qualityregistry.org/StructureDefinition/hemorrhagic-stroke-bleeding-reason-ext"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.extension:wakeupStroke",
      "path" : "Condition.extension",
      "sliceName" : "wakeupStroke",
      "short" : "Wake-up stroke indicator",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://qualityregistry.org/StructureDefinition/wakeup-stroke-ext"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.clinicalStatus",
      "path" : "Condition.clinicalStatus",
      "short" : "Active index diagnosis",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Condition.verificationStatus",
      "path" : "Condition.verificationStatus",
      "short" : "Verification state of diagnosis",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/condition-ver-status"
      }
    },
    {
      "id" : "Condition.category",
      "path" : "Condition.category",
      "short" : "Encounter diagnosis",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Condition.code",
      "path" : "Condition.code",
      "short" : "Final diagnosis code for the stroke episode, including stroke mimics",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://qualityregistry.org/ValueSet/stroke-diagnosis-code-vs"
      }
    },
    {
      "id" : "Condition.bodySite",
      "path" : "Condition.bodySite",
      "short" : "Anatomical site of stroke involvement",
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://qualityregistry.org/ValueSet/body-sites-vs"
      }
    },
    {
      "id" : "Condition.subject",
      "path" : "Condition.subject",
      "short" : "RES-Q registry patient",
      "definition" : "Patient who experienced the index stroke episode represented in this registry dataset.",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://qualityregistry.org/StructureDefinition/resq-patient-profile"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.encounter",
      "path" : "Condition.encounter",
      "short" : "Index stroke encounter",
      "definition" : "Encounter that anchors the clinical fact to the acute stroke episode and hospital pathway.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://qualityregistry.org/StructureDefinition/stroke-encounter-profile"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.onset[x]",
      "path" : "Condition.onset[x]",
      "short" : "Stroke onset or last-known-well date/time",
      "type" : [{
        "code" : "dateTime"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Condition.evidence",
      "path" : "Condition.evidence",
      "short" : "Diagnostic evidence supporting the stroke diagnosis when available in the source system",
      "mustSupport" : true
    }]
  }
}

```
