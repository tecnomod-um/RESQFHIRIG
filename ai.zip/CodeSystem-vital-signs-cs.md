# VitalSignsCs CodeSystem - RESQ Stroke Registry Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VitalSignsCs CodeSystem**

## CodeSystem: VitalSignsCs CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/CodeSystem/vital-signs-cs | *Version*:1.0.0 |
| Active as of 2026-09-04 | *Computable Name*:VitalSignsCS |

 
Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/vital-signs-cs. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VitalSigns ValueSet](ValueSet-vital-signs-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "vital-signs-cs",
  "url" : "http://qualityregistry.org/CodeSystem/vital-signs-cs",
  "version" : "1.0.0",
  "name" : "VitalSignsCS",
  "title" : "VitalSignsCs CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-04T09:44:50+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "Local RESQ stroke registry CodeSystem generated from enum_models.py for system http://qualityregistry.org/CodeSystem/vital-signs-cs.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 1,
  "concept" : [{
    "code" : "highest-sys-bp",
    "display" : "Highest Systolic Blood Pressure"
  }]
}

```
