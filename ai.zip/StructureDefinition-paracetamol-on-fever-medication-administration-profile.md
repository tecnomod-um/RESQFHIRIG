# Paracetamol on Fever MedicationAdministration Profile - RESQ Stroke Registry Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Paracetamol on Fever MedicationAdministration Profile**

## Resource Profile: Paracetamol on Fever MedicationAdministration Profile 

| | |
| :--- | :--- |
| *Official URL*:http://qualityregistry.org/StructureDefinition/paracetamol-on-fever-paracetamol-on-fever-medication-administration-profile | *Version*:1.0.0 |
| Active as of 2026-08-31 | *Computable Name*:ParacetamolOnFeverMedicationAdministrationProfile |

 
MedicationAdministration profile for paracetamol administered because of fever. 

**Usages:**

* This Profile is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/RESQFHIRIG|current/StructureDefinition/StructureDefinition-paracetamol-on-fever-medication-administration-profile.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-paracetamol-on-fever-medication-administration-profile.csv), [Excel](StructureDefinition-paracetamol-on-fever-medication-administration-profile.xlsx), [Schematron](StructureDefinition-paracetamol-on-fever-medication-administration-profile.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "paracetamol-on-fever-medication-administration-profile",
  "url" : "http://qualityregistry.org/StructureDefinition/paracetamol-on-fever-paracetamol-on-fever-medication-administration-profile",
  "version" : "1.0.0",
  "name" : "ParacetamolOnFeverMedicationAdministrationProfile",
  "title" : "Paracetamol on Fever MedicationAdministration Profile",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-31T10:08:26+00:00",
  "publisher" : "Tecnomod / Universidad de Murcia",
  "contact" : [{
    "name" : "Tecnomod / Universidad de Murcia",
    "telecom" : [{
      "system" : "url",
      "value" : "http://qualityregistry.org"
    }]
  }],
  "description" : "MedicationAdministration profile for paracetamol administered because of fever.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ES",
      "display" : "Spain"
    }]
  }],
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 V2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "MedicationAdministration",
  "baseDefinition" : "http://qualityregistry.org/StructureDefinition/stroke-medication-administration-profile",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "MedicationAdministration",
      "path" : "MedicationAdministration"
    },
    {
      "id" : "MedicationAdministration.extension",
      "path" : "MedicationAdministration.extension",
      "min" : 1
    },
    {
      "id" : "MedicationAdministration.extension:assessmentTiming",
      "path" : "MedicationAdministration.extension",
      "sliceName" : "assessmentTiming",
      "min" : 1
    },
    {
      "id" : "MedicationAdministration.extension:assessmentTiming.value[x]",
      "path" : "MedicationAdministration.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://qualityregistry.org/ValueSet/paracetamol-on-fever-timing-vs"
      }
    },
    {
      "id" : "MedicationAdministration.medication.concept",
      "path" : "MedicationAdministration.medication.concept",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "387517004",
          "display" : "Paracetamol (substance)"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "MedicationAdministration.medication.reference",
      "path" : "MedicationAdministration.medication.reference",
      "max" : "0"
    },
    {
      "id" : "MedicationAdministration.reason",
      "path" : "MedicationAdministration.reason",
      "min" : 1,
      "type" : [{
        "code" : "CodeableReference",
        "targetProfile" : ["http://qualityregistry.org/StructureDefinition/fever-observation-profile"]
      }]
    },
    {
      "id" : "MedicationAdministration.reason.concept",
      "path" : "MedicationAdministration.reason.concept",
      "max" : "0"
    },
    {
      "id" : "MedicationAdministration.reason.reference",
      "path" : "MedicationAdministration.reason.reference",
      "min" : 1,
      "mustSupport" : true
    }]
  }
}

```
